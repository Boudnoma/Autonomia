<?php
try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=autonomiadb', 'root', '');

    if (isset($_POST['submit_categorie'])) {
        $nom = $_POST['categorie_nom'];
        $description = $_POST['categorie_description'];

        $stmt = $pdo->prepare("INSERT INTO categories (nom, description) VALUES (?, ?)");
        $stmt->execute([$nom, $description]);

        echo "Catégorie ajoutée avec succès!";
    }

    if (isset($_POST['submit_lien'])) {
        $titre = $_POST['lien_titre'];
        $url = $_POST['lien_url'];
        $categorie_id = $_POST['categorie_id'];
        $description = $_POST['lien_description'];

        $stmt = $pdo->prepare("INSERT INTO liens (categorie_id, titre, url, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([$categorie_id, $titre, $url, $description]);

        echo "Lien ajouté avec succès!";
    }
} catch (Exception $e) {
    echo 'Erreur : ' . $e->getMessage();
}
?>