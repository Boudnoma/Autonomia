<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Catégories et Liens</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Ajouter une Catégorie</h1>
        <form action="process.php" method="POST">
            <div class="form-group">
                <label for="categorie_nom">Nom de la Catégorie</label>
                <input type="text" id="categorie_nom" name="categorie_nom" required>
            </div>
            <div class="form-group">
                <label for="categorie_description">Description de la Catégorie</label>
                <textarea id="categorie_description" name="categorie_description" rows="4" required></textarea>
            </div>
            <button type="submit" name="submit_categorie">Ajouter Catégorie</button>
        </form>

        <h1>Ajouter un Lien</h1>
        <form action="process.php" method="POST">
            <div class="form-group">
                <label for="lien_titre">Titre du Lien</label>
                <input type="text" id="lien_titre" name="lien_titre" required>
            </div>
            <div class="form-group">
                <label for="lien_url">URL du Lien</label>
                <input type="text" id="lien_url" name="lien_url" required>
            </div>
            <div class="form-group">
                <label for="categorie_id">Catégorie</label>
                <select id="categorie_id" name="categorie_id" required>
                    <?php
                    // Connexion à la base de données
                    $pdo = new PDO('mysql:host=localhost;dbname=autonomiadb', 'root', '');
                    $categories = $pdo->query("SELECT id, nom FROM categories")->fetchAll();

                    foreach ($categories as $categorie) {
                        echo "<option value=\"{$categorie['id']}\">{$categorie['nom']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="lien_description">Description du Lien</label>
                <textarea id="lien_description" name="lien_description" rows="4"></textarea>
            </div>
            <button type="submit" name="submit_lien">Ajouter Lien</button>
        </form>
    </div>
    <div>
        <button type="submit" name="submit_lien"><a href="send_message.php">Envoyer un message</a></button>
    </div>
</body>
</html>