<?php

namespace Telegram\Bot\Events;

use League\Event\EventDispatcher;

class LeagueEventDispatcher extends EventDispatcher implements EventDispatcherListenerContract
{
}
