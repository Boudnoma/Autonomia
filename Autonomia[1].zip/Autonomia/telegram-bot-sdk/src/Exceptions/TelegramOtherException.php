<?php

namespace Telegram\Bot\Exceptions;

/**
 * Class TelegramOtherException.
 */
final class TelegramOtherException extends TelegramSDKException
{
}
