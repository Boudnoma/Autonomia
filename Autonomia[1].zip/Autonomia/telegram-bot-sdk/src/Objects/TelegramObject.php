<?php

namespace Telegram\Bot\Objects;

/**
 * Class Object.
 */
class TelegramObject extends BaseObject
{
    /**
     * Property relations.
     */
    public function relations(): array
    {
        return [];
    }
}
