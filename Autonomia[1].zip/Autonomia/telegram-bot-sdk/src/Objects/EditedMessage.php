<?php

namespace Telegram\Bot\Objects;

/**
 * {@inheritdoc}
 */
class EditedMessage extends Message
{
}
