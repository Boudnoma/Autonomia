<?php
require_once 'telegram-bot-sdk/vendor/autoload.php';

use Telegram\Bot\Api;

$bot_token = '7384366152:AAGTxSyn9G_Lv7gpeiYtKfQu_XLIELaIU0s';
$telegram = new Api($bot_token);

// Fonction pour générer les boutons pour chaque lien
function generateLinkButtons($categorie_id, $pdo) {
    $stmt = $pdo->prepare("SELECT titre, url FROM liens WHERE categorie_id = ?");
    $stmt->execute([$categorie_id]);
    $liens = $stmt->fetchAll();

    $buttons = [];
    $row = [];
    
    foreach ($liens as $index => $lien) {
        $row[] = ['text' => $lien['titre'], 'url' => $lien['url']];
        
        // Ajouter une nouvelle ligne lorsque la ligne précédente est remplie
        if (($index + 1) % 3 === 0) { // Change 3 to the number of buttons you want per row
            $buttons[] = $row;
            $row = [];
        }
    }
    
    // Ajouter la dernière ligne si elle contient des boutons
    if (!empty($row)) {
        $buttons[] = $row;
    }
    
    return $buttons;
}

try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=autonomiadb', 'root', '');

    // Récupérer toutes les catégories
    $categories = $pdo->query("SELECT id, nom, description FROM categories")->fetchAll();

    foreach ($categories as $categorie) {
        // Générer les boutons pour chaque lien dans la catégorie
        $keyboard = [
            'inline_keyboard' => generateLinkButtons($categorie['id'], $pdo)
        ];

        // Créer le message à envoyer
        $message = "📂 *Catégorie:* " . $categorie['nom'] . "\n\n";
        $message .= "📝 *Description:* " . $categorie['description'] . "\n\n";
        $message .= "🔗 *Liens:*";

        // Envoyer le message avec les boutons de la catégorie
        $telegram->sendMessage([
            'chat_id' => '@Autonomia_tls', // Remplace par ton canal
            'text' => $message,
            'parse_mode' => 'Markdown', // Utilise Markdown pour la mise en forme
            'reply_markup' => json_encode($keyboard)
        ]);
    }

    echo "Messages envoyés avec succès!";
} catch (Exception $e) {
    echo 'Erreur : ' . $e->getMessage();
}
?>